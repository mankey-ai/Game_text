# -*- coding: utf-8 -*-
import pygame
import sys
import random
import os
import math

pygame.init()

# ============ Path compatibility for local + web WASM ============
BASE_DIR = os.path.dirname(__file__)
ASSETS_FOLDER = "assets"

# Screen settings
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Plane Shooter - Auto Fire + Random Offset")

# Colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
CYAN = (0, 255, 255)
ORANGE = (255, 165, 0)

# ---------- Load images (fallback to default shapes if missing) ----------
try:
    player_path = os.path.join(BASE_DIR, ASSETS_FOLDER, "player.png")
    player_img = pygame.image.load(player_path)
except FileNotFoundError:
    print("player.png not found, using default green triangle")
    player_img = pygame.Surface((50, 50), pygame.SRCALPHA)
    pygame.draw.polygon(player_img, GREEN, [(25, 0), (0, 50), (50, 50)])

try:
    enemy_path = os.path.join(BASE_DIR, ASSETS_FOLDER, "enemy.png")
    enemy_img = pygame.image.load(enemy_path)
except FileNotFoundError:
    print("enemy.png not found, using default red rect")
    enemy_img = pygame.Surface((40, 40), pygame.SRCALPHA)
    enemy_img.fill(RED)

try:
    bullet_path = os.path.join(BASE_DIR, ASSETS_FOLDER, "bullet.png")
    bullet_img = pygame.image.load(bullet_path)
except FileNotFoundError:
    print("bullet.png not found, using default cyan rect")
    bullet_img = pygame.Surface((10, 20), pygame.SRCALPHA)
    bullet_img.fill(CYAN)

try:
    bg_path = os.path.join(BASE_DIR, ASSETS_FOLDER, "bg.jpeg")
    background_img = pygame.image.load(bg_path)
    background_img = pygame.transform.scale(background_img, (SCREEN_WIDTH, SCREEN_HEIGHT))
except FileNotFoundError:
    print("bg.jpeg not found, using black background")
    background_img = None

# Get player rect
player_rect = player_img.get_rect()
player_rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT - 100)

# Game parameters
player_speed = 5
bullet_speed = 8
player_shoot_cooldown = 10
shoot_timer = 0

enemy_speed = 1.8
enemy_bullet_speed = 5
enemy_bullet_lifetime = 80
enemy_spawn_interval = 60
score = 0
game_over = False

player_bullets = []
enemy_bullets = []
enemies = []

clock = pygame.time.Clock()
FPS = 60
enemy_spawn_timer = 0

# Use default font (works in both local and web)
font = pygame.font.Font(None, 36)


def reset_game():
    global player_rect, player_bullets, enemy_bullets, enemies, score, game_over, enemy_spawn_timer, shoot_timer
    player_rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT - 100)
    player_bullets.clear()
    enemy_bullets.clear()
    enemies.clear()
    score = 0
    game_over = False
    enemy_spawn_timer = 0
    shoot_timer = 0


def draw_text(text, x, y, color=WHITE):
    img = font.render(text, True, color)
    screen.blit(img, (x, y))


# Main loop
running = True

while running:
    clock.tick(FPS)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_r and game_over:
            reset_game()

    if game_over:
        screen.fill(BLACK)
        draw_text("Game Over!", SCREEN_WIDTH // 2 - 80, SCREEN_HEIGHT // 2 - 50, RED)
        draw_text(f"Final Score: {score}", SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2, WHITE)
        draw_text("Press R to restart", SCREEN_WIDTH // 2 - 120, SCREEN_HEIGHT // 2 + 50, WHITE)
        pygame.display.flip()
        continue

    # Player controls
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] and player_rect.left > 0:
        player_rect.x -= player_speed
    if keys[pygame.K_RIGHT] and player_rect.right < SCREEN_WIDTH:
        player_rect.x += player_speed
    if keys[pygame.K_UP] and player_rect.top > 0:
        player_rect.y -= player_speed
    if keys[pygame.K_DOWN] and player_rect.bottom < SCREEN_HEIGHT:
        player_rect.y += player_speed

    # Auto fire
    if shoot_timer <= 0:
        offset_deg = random.uniform(-10, 10)
        offset_rad = math.radians(offset_deg)
        vx = bullet_speed * math.sin(offset_rad)
        vy = -bullet_speed * math.cos(offset_rad)
        rotate_angle = -offset_deg

        new_bullet_rect = bullet_img.get_rect()
        new_bullet_rect.centerx = player_rect.centerx
        new_bullet_rect.centery = player_rect.top

        player_bullets.append([new_bullet_rect, vx, vy, rotate_angle])
        shoot_timer = player_shoot_cooldown
    else:
        shoot_timer -= 1

    # Update bullets
    for bullet in player_bullets[:]:
        rect, vx, vy, _ = bullet
        rect.x += vx
        rect.y += vy
        if (rect.right < 0 or rect.left > SCREEN_WIDTH or
                rect.bottom < 0 or rect.top > SCREEN_HEIGHT):
            player_bullets.remove(bullet)

    # Spawn enemies
    enemy_spawn_timer += 1
    if enemy_spawn_timer >= enemy_spawn_interval:
        enemy_spawn_timer = 0
        new_enemy_rect = enemy_img.get_rect()
        new_enemy_rect.x = random.randint(0, SCREEN_WIDTH - new_enemy_rect.width)
        new_enemy_rect.y = -new_enemy_rect.height
        enemies.append(new_enemy_rect)

    # Update enemies
    for enemy in enemies[:]:
        enemy.y += enemy_speed
        if random.random() < 0.15:
            enemy_bullet_rect = pygame.Rect(0, 0, 10, 15)
            enemy_bullet_rect.centerx = enemy.centerx
            enemy_bullet_rect.top = enemy.bottom
            enemy_bullets.append([enemy_bullet_rect, enemy_bullet_speed, enemy_bullet_lifetime])
        if enemy.top > SCREEN_HEIGHT:
            enemies.remove(enemy)

    # Update enemy bullets
    for bullet in enemy_bullets[:]:
        bullet[0].y += bullet[1]
        bullet[2] -= 1
        if bullet[2] <= 0 or bullet[0].top > SCREEN_HEIGHT:
            enemy_bullets.remove(bullet)

    # Collision detection
    for bullet in player_bullets[:]:
        bullet_rect = bullet[0]
        for enemy in enemies[:]:
            if bullet_rect.colliderect(enemy):
                player_bullets.remove(bullet)
                enemies.remove(enemy)
                score += 1
                break

    for enemy in enemies:
        if player_rect.colliderect(enemy):
            game_over = True
            break

    if not game_over:
        for bullet in enemy_bullets:
            if player_rect.colliderect(bullet[0]):
                game_over = True
                break

    # Draw
    if background_img:
        screen.blit(background_img, (0, 0))
    else:
        screen.fill(BLACK)

    screen.blit(player_img, player_rect)

    for enemy in enemies:
        screen.blit(enemy_img, enemy)

    for rect, vx, vy, angle in player_bullets:
        rotated_img = pygame.transform.rotate(bullet_img, angle)
        new_rect = rotated_img.get_rect(center=rect.center)
        screen.blit(rotated_img, new_rect)

    for bullet in enemy_bullets:
        pygame.draw.rect(screen, ORANGE, bullet[0])

    draw_text(f"Score: {score}", 10, 10)

    pygame.display.flip()

pygame.quit()